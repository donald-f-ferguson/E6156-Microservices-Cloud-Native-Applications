/**
 * Created by donaldferguson on 8/26/18.
 */

exports.codes = {
    success: {code: 0, message: "Cool."},
    invalid_query: {code: -1, message: "Template is not cool!"},
    internal_error: {code: -2, message: "Something evil happened."},
    invalid_create_data: {code: -3, message: "Something evil happened."}
};
